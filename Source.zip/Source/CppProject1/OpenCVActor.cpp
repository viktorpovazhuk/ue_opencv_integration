// Fill out your copyright notice in the Description page of Project Settings.

#include "OpenCVActor.h"

#include <opencv2/opencv.hpp>
#include <string>
#include <vector>
#include <exception>

//#include "laser_detector.h"

// Sets default values
AOpenCVActor::AOpenCVActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

void AOpenCVActor::LocateCorner()
{
//    try {
//        //laserDetector->locate_screen_corner_coords();
//
//        int i = camera_idx;
//
//        std::string fmt = "D:/VSProjects/source/repos/camera_calibration/data/test/test%d.jpg";
//        char buf[300];
//        snprintf(buf, sizeof(buf), fmt.c_str(), i);
//        std::string fn{ buf };
//
//        cv::Mat image = cv::imread(fn, 1);
//        UE_LOG(LogTemp, Log, TEXT("Rows: %i, Cols: %i"), image.rows, image.cols);
//
//        laserDetector->locate_screen_corner_coords(image);
//
//        camera_idx = (camera_idx + 1) % 4;
//    }
//    catch (std::exception& ex) {
//        FString error_fstr{ ex.what() };
//        UE_LOG(LogTemp, Warning, TEXT("Error: %s"), *error_fstr);
//    }
}

void AOpenCVActor::LocateLaser()
{
//    try {
//        //std::vector<double> coords = laserDetector->locate_relative_laser_coords();
//
//        cv::Mat aim_mat = cv::imread("D:/VSProjects/source/repos/camera_calibration/data/test/test_aim.jpg", 1);
//        std::vector<double> coords = laserDetector->locate_relative_laser_coords(aim_mat);
//
//        std::string coords_str = std::to_string(coords[0]) + " " + std::to_string(coords[1]);
//        FString coords_fstr{ coords_str.c_str() };
//
//        UE_LOG(LogTemp, Log, TEXT("Coordinates: %s"), *coords_fstr);
//    }
//    catch (std::exception& ex) {
//        FString error_fstr{ ex.what() };
//        UE_LOG(LogTemp, Warning, TEXT("Error: %s"), *error_fstr);
//    }
}

// Called when the game starts or when spawned
void AOpenCVActor::BeginPlay()
{
	Super::BeginPlay();

    cv::VideoCapture cap{ 1 };

    if (!cap.isOpened()) {
        UE_LOG(LogTemp, Log, TEXT("Camera not opened"));
    }

    cv::Mat im;
    cap.read(im);

    cv::imwrite("D:\\opencv_imgs\\im.jpg", im);

    //laserDetector = new LaserDetector(0, 300, 200);

    //laserDetector->open_capture();

    UE_LOG(LogTemp, Log, TEXT("Another implementation of function BeginPlay()"));
}

// Called every frame
void AOpenCVActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AOpenCVActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    //laserDetector->close_capture();

    //delete laserDetector;

    Super::EndPlay(EndPlayReason);
}