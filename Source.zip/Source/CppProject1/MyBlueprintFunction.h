// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "MyBlueprintFunction.generated.h"

/**
 * 
 */
UCLASS()
class CPPPROJECT1_API UMyBlueprintFunction : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

		UFUNCTION(BlueprintCallable, meta = (DisplayName = "Create serial", Keywords = "Create Serial"), Category = SerialLibrary)
		static float CreateSerial();
	
};
