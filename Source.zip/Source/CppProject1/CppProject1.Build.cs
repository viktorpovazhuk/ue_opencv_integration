// Copyright Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;
using System.IO;

public class CppProject1 : ModuleRules
{
    private string ModulePath 
    {
        get { return ModuleDirectory; }
    }

    private string ThirdPartyPath
    {
        get { return Path.GetFullPath(Path.Combine(ModulePath, "../../ThirdParty/")); }
    }

    public CppProject1(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
	
		PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore", "RHI", "RenderCore" });

		PrivateDependencyModuleNames.AddRange(new string[] {  });

		// Uncomment if you are using Slate UI
		// PrivateDependencyModuleNames.AddRange(new string[] { "Slate", "SlateCore" });

		// Uncomment if you are using online features
		// PrivateDependencyModuleNames.Add("OnlineSubsystem");

		// To include OnlineSubsystemSteam, add it to the plugins section in your uproject file with the Enabled attribute set to true

		LoadSerialcLib(Target);
        LoadOpenCV(Target);
        //LoadLaserTool(Target);
    }

    public bool LoadLaserTool(ReadOnlyTargetRules Target)
    {
        // Start OpenCV linking here!
        bool isLibrarySupported = false;

        // Get Library Path 
        string LibPath = "";
        if (Target.Platform == UnrealTargetPlatform.Win64)
        {
            LibPath = @"D:\VSProjects\source\repos\camera_calibration\out\build\x64-Release"; // Path.Combine(ThirdPartyPath, "LaserTool", "Libraries");
            isLibrarySupported = true;
        }
        else
        {
            string Err = string.Format("{0} dedicated server is made to depend on {1}. We want to avoid this, please correct module dependencies.", Target.Platform.ToString(), this.ToString()); System.Console.WriteLine(Err);
        }

        if (isLibrarySupported)
        {
            string includePath = @"D:\VSProjects\source\repos\camera_calibration\laser_tool\include"; //Path.Combine(ThirdPartyPath, "LaserTool", "Includes");

            //Add Include path 
            PublicIncludePaths.AddRange(new string[] { includePath });

            //Add Static Libraries
            PublicAdditionalLibraries.Add(Path.Combine(LibPath, "laser_tool.lib"));

            //Add Dynamic Libraries
            PublicDelayLoadDLLs.Add("laser_tool.dll");
        }

        return isLibrarySupported;
    }

    public bool LoadOpenCV(ReadOnlyTargetRules Target)
    {
        // Start OpenCV linking here!
        bool isLibrarySupported = false;

        // Create OpenCV Path 
        string OpenCVPath = Path.Combine(ThirdPartyPath, "OpenCV");

        // Get Library Path 
        string LibPath = "";
        if (Target.Platform == UnrealTargetPlatform.Win64)
        {
            LibPath = Path.Combine(OpenCVPath, "Libraries", "Win64");
            isLibrarySupported = true;
        }
        else
        {
            string Err = string.Format("{0} dedicated server is made to depend on {1}. We want to avoid this, please correct module dependencies.", Target.Platform.ToString(), this.ToString()); System.Console.WriteLine(Err);
        }

        if (isLibrarySupported)
        {
            //Add Include path 
            PublicIncludePaths.AddRange(new string[] { Path.Combine(OpenCVPath, "Includes") });

            //Add Static Libraries
            PublicAdditionalLibraries.Add(Path.Combine(LibPath, "opencv_world460.lib"));

            //Add Dynamic Libraries
            PublicDelayLoadDLLs.Add("opencv_videoio_ffmpeg460_64.dll");
            PublicDelayLoadDLLs.Add("opencv_world460.dll");
        }

        return isLibrarySupported;
    }

    public bool LoadSerialcLib(ReadOnlyTargetRules Target)
    {
        bool isLibrarySupported = false;

        if (Target.Platform == UnrealTargetPlatform.Win64)
        {
            isLibrarySupported = true;

            string LibrariesPath = Path.Combine(ThirdPartyPath, "Serial", "lib");

            /*
            test your path with:
            using System; // Console.WriteLine("");
            Console.WriteLine("... LibrariesPath -> " + LibrariesPath);
            */

            PublicAdditionalLibraries.Add(Path.Combine(LibrariesPath, "serial.x64.release.lib"));
        }

        if (isLibrarySupported)
        {
            // Include path
            PublicIncludePaths.Add(Path.Combine(ThirdPartyPath, "Serial", "include"));
        }

        return isLibrarySupported;
    }
}
