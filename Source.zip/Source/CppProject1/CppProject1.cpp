// Copyright Epic Games, Inc. All Rights Reserved.

#include "CppProject1.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, CppProject1, "CppProject1" );
