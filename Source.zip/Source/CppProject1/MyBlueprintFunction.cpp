// Fill out your copyright notice in the Description page of Project Settings.


#include "MyBlueprintFunction.h"
//#include "serial/serial.h"

float UMyBlueprintFunction::CreateSerial() {
	//serial::Serial my_serial("COM6", 115200, serial::Timeout::simpleTimeout(3000));

	return 0;
}
